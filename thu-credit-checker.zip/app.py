# 主程式 app.py
import streamlit as st
st.title('學分查詢系統 (DEMO)')